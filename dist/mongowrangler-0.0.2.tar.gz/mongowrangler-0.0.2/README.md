# MongoWrangler
A Python package that abstracts simple CRUD operations into functions